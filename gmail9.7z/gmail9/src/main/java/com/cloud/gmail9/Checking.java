package com.cloud.gmail9;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.bcel.classfile.InnerClass;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByClassName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.ClickElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

    @Test

    public class Checking

     {
	
	
	
	 private String parentWindowHandler;
	  
	 public void  Login() throws InterruptedException, IOException
	
	    {
	    	System.setProperty("webdriver.chrome.driver","D://chromedriver.exe");
	    	WebDriver driver= new ChromeDriver();
	        driver.get("https://accounts.google.com/signin/v2/identifier?continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&service=mail&sacu=1&rip=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin"); //enter the url of ee
	        driver.manage().window().maximize();
	       
	        WebElement okbutton= driver.findElement(By.xpath(".//*[@id='identifierId']"));//xpath of username
	        okbutton.sendKeys("pandey697101@gmail.com");
	        Thread.sleep(3000);

	        
	        
	        driver.findElement(By.xpath(".//*[@id='identifierNext']/content/span")).click(); //use for click button

	        
	        Thread.sleep(3000);

	        
	        
	        driver.findElement(By.xpath(".//*[@id='password']/div[1]/div/div[1]/input")).sendKeys("Tej@5252006");//use for password block
	        driver.findElement(By.xpath(".//*[@id='passwordNext']/content")).click(); //use for click button
	        
	        Thread.sleep(10000);
	       

	       System.out.println("email page is open");

	       System.out.println("to opean the compose tab doing steps further");
	        
	       // Thread.sleep(3000);

	       // driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	       // String Parentwindow= driver.getWindowHandle();
	       // for(String subwindow:driver.getWindowHandles())
	        		
	        	
	        	
	        	//driver.switchTo().window(subwindow);
	        		
	        //WebDriverWait wait = new WebDriverWait(driver, 30);
	      //  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id=':cg']")));   	
	        
	        
	        
	        //driver.findElement(By.xpath(".//*[@id=':cl']")).sendKeys("saratripathi697101@gmail.com");
	        
	       // driver.findElement(By.xpath(".//*[@id=':c3']")).sendKeys("Important document");
	        
	       // driver.findElement(By.xpath(".//*[@id=':bt']")).click(); 
	        
	        
	      //  System.out.println("mailing is done");
	        
	   
	       driver.findElement(By.xpath(".//*[@id=':7f']/div/div[1]")).click(); //xpath of inbox tab  
	       
	       driver.findElement(By.xpath(".//*[@id=':3a']")).click();  //xpath of latest inbox mail 


	        Thread.sleep(5000);
	        String actual_phase1 =driver.findElement(By.xpath(".//*[@class='a3s aXjCH ']")).getText();
	        String expected_error1="This is a Text Message.";
	        Assert.assertEquals(actual_phase1, expected_error1);
	        System.out.println("mailing is done i.e.,     "+actual_phase1);
	         
	       driver.findElement(By.xpath(".//*[@id=':7f']/div/div[1]")).click(); //xpath of inbox tab  
           System.out.println("home page of mail is open");
	       
           driver.findElement(By.cssSelector(".gb_b")).click(); //xpath of google apps
	        Thread.sleep(5000);

	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		    String Parentwindow= driver.getWindowHandle();
		    for(String subwindow:driver.getWindowHandles())
		    driver.switchTo().window(subwindow);
		    
		    driver.findElement(By.xpath(".//*[@id='gb192']")).click();  //xpath of account
		    
		        		
		    Thread.sleep(5000);
		    
		    
	        WebDriverWait wait = new WebDriverWait(driver, 60);

		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@class='ZrQ9j']")));  
		    
	        String actual_phase2 =driver.findElement(By.xpath(".//*[@class='ZrQ9j']")).getText();
	        String expected_error2="Welcome, tanu tripathi";
	        Assert.assertEquals(actual_phase2, expected_error2);
	        System.out.println("google account page is open i.e.,         "+actual_phase2);
	       
	       
	       
	       
	       
	       
	        
	    }
     }
	             
